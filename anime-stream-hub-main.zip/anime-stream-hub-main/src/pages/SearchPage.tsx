import { useState, useEffect, useMemo, useRef } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Filter, X, ChevronDown, Grid3X3, List, SlidersHorizontal, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { animeData, genres, years, qualities, ratings, Anime } from "@/data/animeData";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AnimeCard from "@/components/AnimeCard";
import SearchAutocomplete from "@/components/SearchAutocomplete";
import { useInfiniteScroll } from "@/hooks/useInfiniteScroll";

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Filter states
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedYear, setSelectedYear] = useState<string>("");
  const [selectedQuality, setSelectedQuality] = useState<string>("");
  const [selectedRating, setSelectedRating] = useState<string>("");
  const [selectedType, setSelectedType] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("rating");

  const query = searchParams.get("q") || "";
  const genreParam = searchParams.get("genre");
  const typeParam = searchParams.get("type");
  const sortParam = searchParams.get("sort");

  // Initialize filters from URL params
  useEffect(() => {
    if (genreParam) {
      setSelectedGenres([genreParam]);
    }
  }, [genreParam]);

  useEffect(() => {
    if (typeParam) {
      setSelectedType(typeParam);
    }
  }, [typeParam]);

  useEffect(() => {
    if (sortParam) {
      setSortBy(sortParam);
    }
  }, [sortParam]);

  // Filter and sort anime
  const filteredAnime = useMemo(() => {
    let results = [...animeData];

    // Search query filter
    if (query) {
      results = results.filter(
        (anime) =>
          anime.title.toLowerCase().includes(query.toLowerCase()) ||
          anime.japaneseTitle.toLowerCase().includes(query.toLowerCase()) ||
          anime.synopsis.toLowerCase().includes(query.toLowerCase())
      );
    }

    // Genre filter
    if (selectedGenres.length > 0) {
      results = results.filter((anime) =>
        selectedGenres.some((g) => anime.genre.includes(g))
      );
    }

    // Type filter (Movie / Series)
    if (selectedType) {
      if (selectedType === "Series") {
        results = results.filter((anime) => anime.type !== "Movie");
      } else {
        results = results.filter((anime) => anime.type === selectedType);
      }
    }

    // Year filter
    if (selectedYear) {
      if (selectedYear === "Before 2000") {
        results = results.filter((anime) => parseInt(anime.year) < 2000);
      } else if (selectedYear.includes("-")) {
        const [start, end] = selectedYear.split("-").map(Number);
        results = results.filter((anime) => {
          const year = parseInt(anime.year);
          return year >= start && year <= end;
        });
      } else {
        results = results.filter((anime) => anime.year === selectedYear);
      }
    }

    // Quality filter
    if (selectedQuality) {
      results = results.filter((anime) => anime.quality === selectedQuality);
    }

    // Rating filter
    if (selectedRating && selectedRating !== "Any") {
      const minRating = parseInt(selectedRating);
      results = results.filter((anime) => anime.rating >= minRating);
    }

    // Sort
    switch (sortBy) {
      case "rating":
        results.sort((a, b) => b.rating - a.rating);
        break;
      case "year":
        results.sort((a, b) => parseInt(b.year) - parseInt(a.year));
        break;
      case "title":
        results.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "views":
        results.sort((a, b) => parseFloat(b.views) - parseFloat(a.views));
        break;
    }

    return results;
  }, [query, selectedGenres, selectedType, selectedYear, selectedQuality, selectedRating, sortBy]);

  // Infinite scroll
  const {
    displayedItems,
    hasMore,
    isLoading,
    observerRef,
  } = useInfiniteScroll({
    data: filteredAnime,
    itemsPerPage: 12,
  });

  const handleSearch = (newQuery: string) => {
    setSearchParams({ q: newQuery });
  };

  const toggleGenre = (genre: string) => {
    setSelectedGenres((prev) =>
      prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]
    );
  };

  const clearFilters = () => {
    setSelectedGenres([]);
    setSelectedYear("");
    setSelectedQuality("");
    setSelectedRating("");
    setSelectedType("");
    setSortBy("rating");
  };

  const activeFiltersCount = 
    selectedGenres.length + 
    (selectedYear ? 1 : 0) + 
    (selectedQuality ? 1 : 0) + 
    (selectedType ? 1 : 0) +
    (selectedRating && selectedRating !== "Any" ? 1 : 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">
              {query ? (
                <>
                  Results for <span className="gradient-text">"{query}"</span>
                </>
              ) : genreParam ? (
                <>
                  <span className="gradient-text">{genreParam}</span> Anime
                </>
              ) : typeParam ? (
                <>
                  <span className="gradient-text">{typeParam === "Series" ? "Series" : "Movies"}</span>
                </>
              ) : (
                <>
                  Browse <span className="gradient-text">Anime</span>
                </>
              )}
            </h1>
            <p className="text-muted-foreground">
              {filteredAnime.length} anime found
              {displayedItems.length < filteredAnime.length && (
                <span className="text-primary"> · Showing {displayedItems.length}</span>
              )}
            </p>
          </div>

          {/* Search Bar */}
          <div className="mb-8">
            <SearchAutocomplete
              placeholder="Search anime by title, genre, or description..."
              onSearch={handleSearch}
            />
          </div>

          {/* Filter Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <Button
                variant={showFilters ? "neon" : "outline"}
                onClick={() => setShowFilters(!showFilters)}
                className="gap-2"
              >
                <SlidersHorizontal className="h-4 w-4" />
                Filters
                {activeFiltersCount > 0 && (
                  <span className="ml-1 px-2 py-0.5 bg-primary-foreground/20 rounded-full text-xs">
                    {activeFiltersCount}
                  </span>
                )}
              </Button>

              {activeFiltersCount > 0 && (
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
                  <X className="h-4 w-4 mr-1" />
                  Clear all
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3">
              {/* Sort */}
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none bg-muted border border-border rounded-lg px-4 py-2 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="rating">Top Rated</option>
                  <option value="year">Newest</option>
                  <option value="title">A-Z</option>
                  <option value="views">Most Popular</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              </div>

              {/* View Mode */}
              <div className="flex bg-muted rounded-lg p-1">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === "grid" ? "bg-card text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Grid3X3 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === "list" ? "bg-card text-primary" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Filters Panel */}
          {showFilters && (
            <div className="mb-8 p-6 bg-card border border-border rounded-xl animate-fade-in">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Type */}
                <div>
                  <h3 className="font-medium text-foreground mb-3">Type</h3>
                  <div className="flex flex-wrap gap-2">
                    {["Movie", "Series", "OVA"].map((type) => (
                      <button
                        key={type}
                        onClick={() => setSelectedType(selectedType === type ? "" : type)}
                        className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                          selectedType === type
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Genre */}
                <div>
                  <h3 className="font-medium text-foreground mb-3 flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Genre
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {genres.map((genre) => (
                      <button
                        key={genre}
                        onClick={() => toggleGenre(genre)}
                        className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                          selectedGenres.includes(genre)
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {genre}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Year */}
                <div>
                  <h3 className="font-medium text-foreground mb-3">Year</h3>
                  <div className="relative">
                    <select
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(e.target.value)}
                      className="w-full appearance-none bg-muted border border-border rounded-lg px-4 py-2 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">All Years</option>
                      {years.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                  </div>
                </div>

                {/* Quality */}
                <div>
                  <h3 className="font-medium text-foreground mb-3">Quality</h3>
                  <div className="flex flex-wrap gap-2">
                    {qualities.map((quality) => (
                      <button
                        key={quality}
                        onClick={() => setSelectedQuality(selectedQuality === quality ? "" : quality)}
                        className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                          selectedQuality === quality
                            ? "bg-secondary text-secondary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {quality}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Rating */}
                <div>
                  <h3 className="font-medium text-foreground mb-3">Minimum Rating</h3>
                  <div className="flex flex-wrap gap-2">
                    {ratings.map((rating) => (
                      <button
                        key={rating}
                        onClick={() => setSelectedRating(selectedRating === rating ? "" : rating)}
                        className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                          selectedRating === rating
                            ? "bg-yellow-500/20 text-yellow-400"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {rating === "Any" ? rating : `★ ${rating}`}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Results */}
          {filteredAnime.length > 0 ? (
            viewMode === "grid" ? (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                  {displayedItems.map((anime) => (
                    <Link key={anime.id} to={`/anime/${anime.id}`}>
                      <AnimeCard
                        title={anime.title}
                        image={anime.image}
                        rating={anime.rating}
                        year={anime.year}
                        genre={anime.genre[0]}
                      />
                    </Link>
                  ))}
                </div>
                
                {/* Infinite scroll trigger */}
                <div ref={observerRef} className="flex justify-center py-8">
                  {isLoading && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Loader2 className="h-5 w-5 animate-spin" />
                      <span>Loading more...</span>
                    </div>
                  )}
                  {!hasMore && displayedItems.length > 0 && (
                    <p className="text-muted-foreground text-sm">You've reached the end</p>
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="space-y-4">
                  {displayedItems.map((anime) => (
                    <Link
                      key={anime.id}
                      to={`/anime/${anime.id}`}
                      className="flex gap-4 p-4 bg-card border border-border rounded-xl hover:border-primary/50 transition-colors group"
                    >
                      <img
                        src={anime.image}
                        alt={anime.title}
                        className="w-24 h-36 object-cover rounded-lg"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="px-2 py-0.5 bg-primary/20 text-primary text-xs rounded">
                            {anime.type}
                          </span>
                          <span className="px-2 py-0.5 bg-muted text-muted-foreground text-xs rounded">
                            {anime.quality}
                          </span>
                        </div>
                        <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors truncate">
                          {anime.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-2">
                          {anime.japaneseTitle}
                        </p>
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                          {anime.synopsis}
                        </p>
                        <div className="flex flex-wrap items-center gap-4 text-sm">
                          <span className="flex items-center gap-1 text-yellow-500">
                            ★ {anime.rating}
                          </span>
                          <span className="text-muted-foreground">{anime.year}</span>
                          <span className="text-muted-foreground">{anime.studio}</span>
                          <div className="flex gap-1">
                            {anime.genre.slice(0, 3).map((g) => (
                              <span key={g} className="text-muted-foreground">
                                {g}{anime.genre.indexOf(g) < 2 && anime.genre.length > 1 ? "," : ""}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
                
                {/* Infinite scroll trigger */}
                <div ref={observerRef} className="flex justify-center py-8">
                  {isLoading && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Loader2 className="h-5 w-5 animate-spin" />
                      <span>Loading more...</span>
                    </div>
                  )}
                  {!hasMore && displayedItems.length > 0 && (
                    <p className="text-muted-foreground text-sm">You've reached the end</p>
                  )}
                </div>
              </>
            )
          ) : (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">No anime found</h3>
              <p className="text-muted-foreground mb-6">
                Try adjusting your search or filters
              </p>
              <Button variant="neon" onClick={clearFilters}>
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default SearchPage;
