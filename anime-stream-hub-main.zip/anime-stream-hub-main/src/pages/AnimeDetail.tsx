import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { 
  ArrowLeft, Star, Calendar, Clock, Eye, Play, Download, 
  Share2, ChevronDown, ChevronUp, ExternalLink 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { animeData, Anime } from "@/data/animeData";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import AnimeCard from "@/components/AnimeCard";
import CommentSection from "@/components/CommentSection";
import AnimeInfoCard from "@/components/AnimeInfoCard";

const AnimeDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [expandedEpisode, setExpandedEpisode] = useState<string | null>(null);
  

  const anime = animeData.find((a) => a.id === id);

  if (!anime) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-display font-bold mb-4">Anime Not Found</h1>
          <Link to="/">
            <Button variant="neon">Go Back Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Get related anime (same genre, different anime)
  const relatedAnime = animeData
    .filter((a) => a.id !== anime.id && a.genre.some((g) => anime.genre.includes(g)))
    .slice(0, 6);

  const toggleEpisode = (episodeId: string) => {
    setExpandedEpisode(expandedEpisode === episodeId ? null : episodeId);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Banner */}
      <section className="relative pt-20">
        <div
          className="absolute inset-0 h-[500px] bg-cover bg-center"
          style={{ backgroundImage: `url(${anime.coverImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background/50" />
        </div>

        <div className="relative container mx-auto px-4 pt-12 pb-8">
          {/* Back Button */}
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Poster */}
            <div className="flex-shrink-0">
              <div className="relative w-64 mx-auto lg:mx-0 anime-card overflow-hidden">
                <img
                  src={anime.image}
                  alt={anime.title}
                  className="w-full aspect-[2/3] object-cover"
                />
                <div className="absolute top-3 right-3 px-2 py-1 rounded-md bg-primary/90 backdrop-blur-sm">
                  <span className="text-xs font-bold text-primary-foreground">
                    {anime.quality}
                  </span>
                </div>
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 space-y-6">
              {/* Title */}
              <div>
                <div className="flex flex-wrap items-center gap-3 mb-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    anime.status === "Ongoing" 
                      ? "bg-green-500/20 text-green-400" 
                      : anime.status === "Completed"
                      ? "bg-primary/20 text-primary"
                      : "bg-yellow-500/20 text-yellow-400"
                  }`}>
                    {anime.status}
                  </span>
                  <span className="text-muted-foreground text-sm">{anime.type}</span>
                </div>
                <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-2">
                  {anime.title}
                </h1>
                <p className="text-muted-foreground text-lg">{anime.japaneseTitle}</p>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap items-center gap-6 text-sm">
                <div className="flex items-center gap-1.5">
                  <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                  <span className="font-semibold text-foreground">{anime.rating}</span>
                  <span className="text-muted-foreground">/ 10</span>
                </div>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  {anime.year}
                </div>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {anime.duration}
                </div>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Eye className="h-4 w-4" />
                  {anime.views} views
                </div>
              </div>

              {/* Genres */}
              <div className="flex flex-wrap gap-2">
                {anime.genre.map((genre) => (
                  <Link
                    key={genre}
                    to={`/search?genre=${encodeURIComponent(genre)}`}
                    className="px-3 py-1.5 bg-muted rounded-full text-sm text-foreground hover:bg-primary/20 hover:text-primary transition-colors"
                  >
                    {genre}
                  </Link>
                ))}
              </div>

              {/* Studio */}
              <p className="text-muted-foreground">
                <span className="text-foreground">Studio:</span> {anime.studio}
              </p>

              {/* Actions */}
              <div className="flex flex-wrap gap-3">
                <Button variant="neon" size="xl">
                  <Play className="h-5 w-5 fill-current" />
                  Watch Now
                </Button>
                <Button variant="neonOutline" size="xl">
                  <Download className="h-5 w-5" />
                  Download
                </Button>
                <Button variant="outline" size="icon" className="h-14 w-14">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Synopsis & Info Card */}
      <section className="py-12 bg-surface-darker">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Synopsis */}
            <div className="lg:col-span-2">
              <h2 className="font-display text-2xl font-bold mb-4">Synopsis</h2>
              <p className="text-muted-foreground leading-relaxed">
                {anime.synopsis}
              </p>
            </div>

            {/* Info Card */}
            <div className="lg:col-span-1">
              <AnimeInfoCard anime={anime} />
            </div>
          </div>
        </div>
      </section>

      {/* Episodes */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-2xl font-bold mb-6">
            Episodes <span className="text-muted-foreground font-normal text-lg">({anime.episodes.length})</span>
          </h2>

          <div className="space-y-4">
            {anime.episodes.map((episode) => (
              <div
                key={episode.id}
                className="bg-card border border-border rounded-xl overflow-hidden"
              >
                {/* Episode Header */}
                <button
                  onClick={() => toggleEpisode(episode.id)}
                  className="w-full flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors text-left"
                >
                  <img
                    src={episode.thumbnail}
                    alt={episode.title}
                    className="w-32 h-20 object-cover rounded-lg hidden sm:block"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-primary font-semibold">EP {episode.number}</span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-muted-foreground text-sm">{episode.duration}</span>
                    </div>
                    <h3 className="font-medium text-foreground truncate">{episode.title}</h3>
                    <div className="flex gap-2 mt-2">
                      {episode.quality.map((q) => (
                        <span key={q} className="px-2 py-0.5 bg-muted rounded text-xs text-muted-foreground">
                          {q}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button variant="neon" size="sm" className="hidden sm:flex">
                      <Play className="h-4 w-4 fill-current" />
                      Watch
                    </Button>
                    {expandedEpisode === episode.id ? (
                      <ChevronUp className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                </button>

                {/* Download Links */}
                {expandedEpisode === episode.id && (
                  <div className="border-t border-border p-4 bg-muted/30 animate-fade-in">
                    <h4 className="font-medium text-foreground mb-3 flex items-center gap-2">
                      <Download className="h-4 w-4" />
                      Download Links
                    </h4>
                    <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
                      {episode.downloadLinks.map((link) => (
                        <a
                          key={link.quality}
                          href={link.url}
                          className="flex items-center justify-between p-3 bg-card border border-border rounded-lg hover:border-primary/50 hover:bg-primary/5 transition-colors group"
                        >
                          <div>
                            <span className="font-medium text-foreground">{link.quality}</span>
                            <span className="block text-xs text-muted-foreground">{link.size}</span>
                          </div>
                          <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Related Anime */}
      {relatedAnime.length > 0 && (
        <section className="py-12 bg-surface-darker">
          <div className="container mx-auto px-4">
            <h2 className="font-display text-2xl font-bold mb-6">
              Related <span className="gradient-text">Recommendations</span>
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-6">
              {relatedAnime.map((related) => (
                <Link key={related.id} to={`/anime/${related.id}`}>
                  <AnimeCard
                    title={related.title}
                    image={related.image}
                    rating={related.rating}
                    year={related.year}
                    genre={related.genre[0]}
                  />
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Comments Section */}
      <CommentSection animeId={anime.id} />

      <Footer />
    </div>
  );
};

export default AnimeDetail;
