import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Shield, Mail, AlertTriangle, FileText } from "lucide-react";

const DMCAPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Shield className="h-8 w-8 text-primary" />
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">
              <span className="gradient-text">DMCA</span> Policy
            </h1>
            <p className="text-muted-foreground">
              Digital Millennium Copyright Act Notice
            </p>
          </div>

          {/* Content */}
          <div className="space-y-8">
            {/* Disclaimer */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <div className="flex items-start gap-4">
                <AlertTriangle className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
                <div>
                  <h2 className="font-semibold text-lg mb-2">Disclaimer</h2>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    iKillAnime Hub does not host any files on our servers. All content is provided by non-affiliated third parties. 
                    We are not responsible for any content linked to or referred to from these pages. 
                    If you believe that your copyrighted content is being infringed upon, please follow the procedure below.
                  </p>
                </div>
              </div>
            </section>

            {/* Filing a DMCA Notice */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <div className="flex items-start gap-4">
                <FileText className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h2 className="font-semibold text-lg mb-2">Filing a DMCA Notice</h2>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement, 
                    please provide our DMCA agent with the following information:
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>A physical or electronic signature of the copyright owner or a person authorized to act on their behalf</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>Identification of the copyrighted work claimed to have been infringed</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>Identification of the material that is claimed to be infringing and where it is located on the site (URL)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>Your address, telephone number, and email address</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>A statement that you have a good faith belief that use of the material is not authorized by the copyright owner</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>A statement, under penalty of perjury, that the above information is accurate</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Contact */}
            <section className="p-6 rounded-xl bg-primary/5 border border-primary/20">
              <div className="flex items-start gap-4">
                <Mail className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h2 className="font-semibold text-lg mb-2">Contact Our DMCA Agent</h2>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    Please send your DMCA notice to our designated agent:
                  </p>
                  <a 
                    href="mailto:dmca@animevault.com" 
                    className="text-primary hover:underline font-medium"
                  >
                    dmca@animevault.com
                  </a>
                  <p className="text-muted-foreground text-xs mt-4">
                    We will respond to valid DMCA requests within 24-48 business hours.
                  </p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default DMCAPage;
