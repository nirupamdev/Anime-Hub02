import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { 
  Plus, Edit, Trash2, Search, Film, LayoutDashboard, 
  List, Settings, ChevronDown, Eye, Download, Star,
  ArrowLeft, Save, X, LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { animeData, Anime, genres, qualities } from "@/data/animeData";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

type TabType = "dashboard" | "anime" | "episodes" | "settings";

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState<TabType>("dashboard");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Mock stats
  const stats = {
    totalAnime: animeData.length,
    totalEpisodes: animeData.reduce((acc, anime) => acc + anime.episodes.length, 0),
    totalViews: "142.5M",
    totalDownloads: "45.2M",
  };

  // Filter anime based on search
  const filteredAnime = animeData.filter((anime) =>
    anime.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const tabs = [
    { id: "dashboard" as TabType, label: "Dashboard", icon: LayoutDashboard },
    { id: "anime" as TabType, label: "Anime", icon: Film },
    { id: "episodes" as TabType, label: "Episodes", icon: List },
    { id: "settings" as TabType, label: "Settings", icon: Settings },
  ];

  const handleLogout = async () => {
    await signOut();
    toast({
      title: "Logged out",
      description: "You have been signed out successfully.",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-surface-dark/95 backdrop-blur-lg border-b border-border">
        <div className="flex items-center justify-between h-16 px-6">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Back to Site</span>
            </Link>
            <div className="h-6 w-px bg-border" />
            <h1 className="font-display font-bold text-xl gradient-text">Admin Panel</h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                className="pl-10 w-64 bg-muted"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            {/* Admin Info & Logout */}
            <div className="flex items-center gap-3 pl-3 border-l border-border">
              <span className="text-sm text-muted-foreground hidden sm:inline">
                {user?.email}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="gap-2 text-muted-foreground hover:text-foreground"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex pt-16">
        {/* Sidebar */}
        <aside className="fixed left-0 top-16 bottom-0 w-64 bg-surface-dark border-r border-border hidden lg:block">
          <nav className="p-4 space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === tab.id
                    ? "bg-primary/20 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                <tab.icon className="h-5 w-5" />
                {tab.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Mobile Tabs */}
        <div className="lg:hidden fixed top-16 left-0 right-0 bg-surface-dark border-b border-border z-40">
          <div className="flex overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "text-primary border-b-2 border-primary"
                    : "text-muted-foreground"
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <main className="flex-1 lg:ml-64 p-6 pt-20 lg:pt-6">
          {/* Dashboard */}
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl font-bold">Dashboard Overview</h2>
              
              {/* Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "Total Anime", value: stats.totalAnime, icon: Film, color: "primary" },
                  { label: "Total Episodes", value: stats.totalEpisodes, icon: List, color: "secondary" },
                  { label: "Total Views", value: stats.totalViews, icon: Eye, color: "accent" },
                  { label: "Downloads", value: stats.totalDownloads, icon: Download, color: "primary" },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <stat.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="font-display text-3xl font-bold text-foreground mb-1">
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* Recent Activity */}
              <div className="bg-card border border-border rounded-xl p-6">
                <h3 className="font-display text-lg font-bold mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {[
                    { action: "New anime added", item: "Solo Leveling Season 2", time: "2 hours ago" },
                    { action: "Episode uploaded", item: "Frieren EP 24", time: "5 hours ago" },
                    { action: "Quality updated", item: "Demon Slayer S4 - 4K", time: "1 day ago" },
                    { action: "New anime added", item: "Chainsaw Man Part 2", time: "2 days ago" },
                  ].map((activity, i) => (
                    <div key={i} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                      <div>
                        <span className="text-muted-foreground">{activity.action}: </span>
                        <span className="text-foreground font-medium">{activity.item}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">{activity.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Anime Management */}
          {activeTab === "anime" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <h2 className="font-display text-2xl font-bold">Anime Management</h2>
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="neon" className="gap-2">
                      <Plus className="h-4 w-4" />
                      Add New Anime
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="font-display">Add New Anime</DialogTitle>
                    </DialogHeader>
                    <AddAnimeForm onClose={() => setIsAddDialogOpen(false)} />
                  </DialogContent>
                </Dialog>
              </div>

              {/* Search for mobile */}
              <div className="lg:hidden">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search anime..."
                    className="pl-10 bg-muted"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              {/* Anime Table */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground">Anime</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground hidden md:table-cell">Status</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground hidden lg:table-cell">Quality</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground hidden sm:table-cell">Episodes</th>
                        <th className="text-left px-6 py-4 text-sm font-medium text-muted-foreground hidden lg:table-cell">Rating</th>
                        <th className="text-right px-6 py-4 text-sm font-medium text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredAnime.map((anime) => (
                        <tr key={anime.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={anime.image}
                                alt={anime.title}
                                className="w-12 h-16 object-cover rounded-lg"
                              />
                              <div className="min-w-0">
                                <div className="font-medium text-foreground truncate max-w-[200px]">
                                  {anime.title}
                                </div>
                                <div className="text-sm text-muted-foreground">{anime.year}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 hidden md:table-cell">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              anime.status === "Ongoing" 
                                ? "bg-green-500/20 text-green-400" 
                                : anime.status === "Completed"
                                ? "bg-primary/20 text-primary"
                                : "bg-yellow-500/20 text-yellow-400"
                            }`}>
                              {anime.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 hidden lg:table-cell">
                            <span className="px-2 py-1 bg-muted rounded text-xs">
                              {anime.quality}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-muted-foreground hidden sm:table-cell">
                            {anime.episodes.length}
                          </td>
                          <td className="px-6 py-4 hidden lg:table-cell">
                            <span className="flex items-center gap-1 text-yellow-500">
                              <Star className="h-3 w-3 fill-current" />
                              {anime.rating}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-end gap-2">
                              <Link to={`/anime/${anime.id}`}>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </Link>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Episodes Tab */}
          {activeTab === "episodes" && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl font-bold">Episodes Management</h2>
              
              <div className="bg-card border border-border rounded-xl p-6">
                <p className="text-muted-foreground mb-4">
                  Select an anime to manage its episodes:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {animeData.slice(0, 6).map((anime) => (
                    <button
                      key={anime.id}
                      onClick={() => setSelectedAnime(anime)}
                      className={`flex items-center gap-3 p-4 rounded-lg border transition-colors text-left ${
                        selectedAnime?.id === anime.id
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <img
                        src={anime.image}
                        alt={anime.title}
                        className="w-12 h-16 object-cover rounded-lg"
                      />
                      <div className="min-w-0">
                        <div className="font-medium text-foreground truncate">{anime.title}</div>
                        <div className="text-sm text-muted-foreground">
                          {anime.episodes.length} episodes
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {selectedAnime && (
                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-display text-lg font-bold">{selectedAnime.title} - Episodes</h3>
                    <Button variant="neon" size="sm" className="gap-2">
                      <Plus className="h-4 w-4" />
                      Add Episode
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {selectedAnime.episodes.map((episode) => (
                      <div
                        key={episode.id}
                        className="flex items-center justify-between p-4 bg-muted/30 rounded-lg"
                      >
                        <div className="flex items-center gap-4">
                          <span className="text-primary font-semibold">EP {episode.number}</span>
                          <span className="text-foreground">{episode.title}</span>
                          <span className="text-muted-foreground text-sm">{episode.duration}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Settings Tab */}
          {activeTab === "settings" && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl font-bold">Settings</h2>
              
              <div className="max-w-2xl space-y-6">
                <div className="bg-card border border-border rounded-xl p-6">
                  <h3 className="font-display text-lg font-bold mb-4">Site Settings</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Site Name
                      </label>
                      <Input defaultValue="iKillAnime Hub" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Site Description
                      </label>
                      <Input defaultValue="Your Ultimate Anime Collection" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Contact Email
                      </label>
                      <Input defaultValue="admin@animevault.com" />
                    </div>
                  </div>
                </div>

                <div className="bg-card border border-border rounded-xl p-6">
                  <h3 className="font-display text-lg font-bold mb-4">Content Settings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-foreground">Enable Comments</div>
                        <div className="text-sm text-muted-foreground">Allow users to comment on anime</div>
                      </div>
                      <Button variant="outline" size="sm">Enabled</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-foreground">Moderate Comments</div>
                        <div className="text-sm text-muted-foreground">Require approval for new comments</div>
                      </div>
                      <Button variant="outline" size="sm">Disabled</Button>
                    </div>
                  </div>
                </div>

                <Button variant="neon" className="gap-2">
                  <Save className="h-4 w-4" />
                  Save Settings
                </Button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

// Add Anime Form Component
const AddAnimeForm = ({ onClose }: { onClose: () => void }) => {
  return (
    <form className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Title (English) *
          </label>
          <Input placeholder="e.g., Demon Slayer" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Title (Japanese)
          </label>
          <Input placeholder="e.g., 鬼滅の刃" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Year *
          </label>
          <Input type="number" placeholder="2024" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Quality *
          </label>
          <select className="w-full h-12 rounded-lg border border-border bg-muted px-4">
            {qualities.map((q) => (
              <option key={q} value={q}>{q}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Type *
          </label>
          <select className="w-full h-12 rounded-lg border border-border bg-muted px-4">
            <option value="Movie">Movie</option>
            <option value="Series">Series</option>
            <option value="OVA">OVA</option>
            <option value="Special">Special</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Genres *
        </label>
        <div className="flex flex-wrap gap-2">
          {genres.map((genre) => (
            <label
              key={genre}
              className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full cursor-pointer hover:bg-muted/80 transition-colors"
            >
              <input type="checkbox" className="sr-only" />
              <span className="text-sm text-muted-foreground">{genre}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Synopsis *
        </label>
        <textarea
          rows={4}
          className="w-full rounded-lg border border-border bg-muted px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          placeholder="Enter anime synopsis..."
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Cover Image URL
          </label>
          <Input placeholder="https://..." />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Poster Image URL
          </label>
          <Input placeholder="https://..." />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <DialogClose asChild>
          <Button variant="outline" type="button">
            Cancel
          </Button>
        </DialogClose>
        <Button variant="neon" type="submit">
          <Plus className="h-4 w-4 mr-2" />
          Add Anime
        </Button>
      </div>
    </form>
  );
};

export default AdminPanel;
