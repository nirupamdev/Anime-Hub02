import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Scale, FileText, ExternalLink, Image, AlertTriangle, Shield, Mail } from "lucide-react";

const TermsPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Scale className="h-8 w-8 text-primary" />
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">
              <span className="gradient-text">Terms of</span> Service
            </h1>
            <p className="text-muted-foreground">
              Last updated: February 2026
            </p>
          </div>

          {/* Content */}
          <div className="space-y-8">
            <p className="text-muted-foreground leading-relaxed">
              Welcome to iKillAnime Hub. By accessing or using this website, you agree to be bound by these Terms of Service. 
              If you do not agree, please stop using the site.
            </p>

            {/* Section 1 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                1. Description of Service
              </h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>iKillAnime Hub is an anime information and community link platform.</p>
                <p className="mt-2">We:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Provide anime/movie/series information</li>
                  <li>Display user or community-submitted external links</li>
                  <li className="font-medium text-foreground">Do NOT host any video or media files on our servers</li>
                </ul>
                <p className="mt-2">All downloadable or streaming content is hosted on third-party platforms.</p>
              </div>
            </section>

            {/* Section 2 */}
            <section className="p-6 rounded-xl bg-yellow-500/5 border border-yellow-500/20">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                2. No File Hosting
              </h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>We do not:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Store movies or episodes</li>
                  <li>Stream copyrighted content</li>
                  <li>Control third-party file hosts</li>
                </ul>
                <p className="mt-2 font-medium text-foreground">We only provide links for informational purposes.</p>
                <p>You access external links at your own risk.</p>
              </div>
            </section>

            {/* Section 3 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">3. User Responsibility</h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>By using this website, you agree that:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>You are responsible for how you use external links</li>
                  <li>You will comply with local laws in your country</li>
                  <li>You will not misuse this website</li>
                </ul>
                <p className="mt-2">We are not responsible for any actions taken by users on third-party platforms.</p>
              </div>
            </section>

            {/* Section 4 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Image className="h-5 w-5 text-primary" />
                4. Intellectual Property
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                All website design, layout, logos, and original content belong to iKillAnime Hub unless otherwise stated.
                You may not copy or redistribute our content without permission.
              </p>
            </section>

            {/* Section 5 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <ExternalLink className="h-5 w-5 text-primary" />
                5. External Websites
              </h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>Our site contains links to third-party websites.</p>
                <p>We do not control and are not responsible for:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Their content</li>
                  <li>Their availability</li>
                  <li>Their privacy practices</li>
                </ul>
                <p className="mt-2">Visiting external sites is at your own discretion.</p>
              </div>
            </section>

            {/* Section 6 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">6. Advertisements</h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>We may display advertisements and promotional content.</p>
                <p>We are not responsible for:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Products or services offered by advertisers</li>
                  <li>Any loss or damage caused by ads</li>
                </ul>
                <p className="mt-2">Any transactions are strictly between you and the advertiser.</p>
              </div>
            </section>

            {/* Section 7 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                7. DMCA / Copyright Policy
              </h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>If you believe copyrighted material is linked on our website, contact us at:</p>
                <a href="mailto:dmca@animevault.com" className="text-primary hover:underline block mt-2">
                  dmca@animevault.com
                </a>
                <p className="mt-2">Provide:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Proof of ownership</li>
                  <li>The exact URL</li>
                  <li>Description of the content</li>
                </ul>
                <p className="mt-2">Valid requests will be processed within 24–48 hours.</p>
              </div>
            </section>

            {/* Section 8 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">8. Disclaimer</h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>All content is provided "as is".</p>
                <p>We make no warranties regarding:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Accuracy</li>
                  <li>Availability</li>
                  <li>Reliability</li>
                </ul>
                <p className="mt-2">We are not liable for any direct or indirect damages resulting from use of this website.</p>
              </div>
            </section>

            {/* Section 9 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">9. Limitation of Liability</h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>iKillAnime Hub and its owners shall not be liable for:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Data loss</li>
                  <li>Legal issues arising from third-party links</li>
                  <li>Service interruptions</li>
                  <li>User actions</li>
                </ul>
                <p className="mt-2 font-medium text-foreground">Use of this website is entirely at your own risk.</p>
              </div>
            </section>

            {/* Section 10-12 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">10. Changes to Terms</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We may modify these Terms at any time. Continued use of the site means you accept the updated Terms.
              </p>
            </section>

            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">11. Termination</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We reserve the right to block or terminate access to any user who violates these Terms or abuses the platform.
              </p>
            </section>

            <section className="p-6 rounded-xl bg-primary/5 border border-primary/20">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                12. Contact Information
              </h2>
              <p className="text-muted-foreground text-sm mb-2">
                For questions regarding these Terms:
              </p>
              <a href="mailto:contact@animevault.com" className="text-primary hover:underline font-medium">
                contact@animevault.com
              </a>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default TermsPage;
