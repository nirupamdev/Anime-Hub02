import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { FileText, Cookie, ExternalLink, Users, Shield, Mail, RefreshCcw, Check } from "lucide-react";

const PrivacyPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <FileText className="h-8 w-8 text-primary" />
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">
              <span className="gradient-text">Privacy</span> Policy
            </h1>
            <p className="text-muted-foreground">
              Last updated: February 2026
            </p>
          </div>

          {/* Content */}
          <div className="space-y-8">
            <p className="text-muted-foreground leading-relaxed">
              Welcome to iKillAnime Hub ("we," "our," or "us"). Your privacy is important to us. 
              This Privacy Policy explains how we collect, use, and protect your information when you visit our website.
              By using this website, you agree to the terms of this Privacy Policy.
            </p>

            {/* Section 1 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                1. Information We Collect
              </h2>
              <div className="space-y-4 text-muted-foreground text-sm">
                <div>
                  <h3 className="font-medium text-foreground mb-2">a) Personal Information</h3>
                  <p>You may voluntarily provide personal information such as:</p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>Name</li>
                    <li>Email address</li>
                  </ul>
                  <p className="mt-2">This usually happens when you contact us or submit a takedown request.</p>
                </div>
                <div>
                  <h3 className="font-medium text-foreground mb-2">b) Non-Personal Information</h3>
                  <p>We automatically collect certain non-personal information, including:</p>
                  <ul className="list-disc pl-6 mt-2 space-y-1">
                    <li>IP address</li>
                    <li>Browser type</li>
                    <li>Device type</li>
                    <li>Pages visited</li>
                    <li>Time and date of visits</li>
                  </ul>
                  <p className="mt-2">This data is used only for analytics and improving website performance.</p>
                </div>
              </div>
            </section>

            {/* Section 2 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Cookie className="h-5 w-5 text-primary" />
                2. Cookies
              </h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>We use cookies to:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Improve user experience</li>
                  <li>Remember preferences</li>
                  <li>Serve advertisements</li>
                  <li>Analyze traffic</li>
                </ul>
                <p className="mt-2">You can disable cookies through your browser settings. Disabling cookies may affect some site features.</p>
              </div>
            </section>

            {/* Section 3 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">3. Advertising Partners</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We may display advertisements from third-party ad networks. These advertisers may use cookies, 
                JavaScript, or web beacons to personalize ads and measure effectiveness. We do not control these cookies.
                Please consult the respective ad networks' privacy policies for more detailed information about their practices.
              </p>
            </section>

            {/* Section 4 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <ExternalLink className="h-5 w-5 text-primary" />
                4. External Links
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Our website contains links to third-party platforms and community sources. 
                We do not control these external websites and are not responsible for their content or privacy practices. 
                Once you leave our site, this Privacy Policy no longer applies.
              </p>
            </section>

            {/* Section 5 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">5. Children's Information</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                iKillAnime Hub does not knowingly collect personal information from children under the age of 13. 
                If you believe your child has provided personal data on our website, please contact us immediately and we will remove it.
              </p>
            </section>

            {/* Section 6 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Check className="h-5 w-5 text-primary" />
                6. How We Use Your Information
              </h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>We use collected information to:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Operate and maintain the website</li>
                  <li>Improve content and user experience</li>
                  <li>Respond to inquiries and takedown requests</li>
                  <li>Prevent abuse and fraud</li>
                </ul>
                <p className="mt-2 font-medium text-foreground">We do not sell or rent your personal information.</p>
              </div>
            </section>

            {/* Section 7 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                7. Data Security
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We take reasonable measures to protect your information. However, no method of transmission over 
                the internet is 100% secure, and we cannot guarantee absolute security.
              </p>
            </section>

            {/* Section 8 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">8. DMCA / Copyright</h2>
              <div className="text-muted-foreground text-sm space-y-2">
                <p>We respect copyright laws. If you believe any content on our site infringes your copyright, please contact us at:</p>
                <a href="mailto:dmca@animevault.com" className="text-primary hover:underline block mt-2">
                  dmca@animevault.com
                </a>
                <p className="mt-2">Include:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Your name</li>
                  <li>The copyrighted work</li>
                  <li>The URL on our site</li>
                  <li>Proof of ownership</li>
                </ul>
                <p className="mt-2">We will review and remove reported content within 24–48 hours.</p>
              </div>
            </section>

            {/* Section 9-11 */}
            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4">9. Consent</h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                By using our website, you consent to this Privacy Policy.
              </p>
            </section>

            <section className="p-6 rounded-xl bg-card border border-border">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <RefreshCcw className="h-5 w-5 text-primary" />
                10. Updates
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                We may update this Privacy Policy from time to time. Any changes will be posted on this page.
              </p>
            </section>

            <section className="p-6 rounded-xl bg-primary/5 border border-primary/20">
              <h2 className="font-semibold text-lg mb-4 flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                11. Contact Us
              </h2>
              <p className="text-muted-foreground text-sm mb-2">
                If you have any questions about this Privacy Policy, contact us at:
              </p>
              <a href="mailto:contact@animevault.com" className="text-primary hover:underline font-medium">
                contact@animevault.com
              </a>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PrivacyPage;
