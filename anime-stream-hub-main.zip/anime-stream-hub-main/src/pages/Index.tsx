import Navbar from "@/components/Navbar";
import FeaturedSlider from "@/components/FeaturedSlider";
import AdPlaceholder from "@/components/AdPlaceholder";
import LatestAnimeGrid from "@/components/LatestAnimeGrid";
import MoviesRow from "@/components/MoviesRow";
import SeriesRow from "@/components/SeriesRow";
import TrendingRow from "@/components/TrendingRow";
import GenresPills from "@/components/GenresPills";
import RecentlyAdded from "@/components/RecentlyAdded";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* 1. Header */}
      <Navbar />
      
      {/* 2. Featured Slider (Hero) */}
      <FeaturedSlider />
      
      {/* Banner Ad Placeholder */}
      <AdPlaceholder size="banner" className="bg-surface-darker" />
      
      {/* 3. Latest Anime Grid */}
      <LatestAnimeGrid />
      
      {/* Mid-Page Ad */}
      <AdPlaceholder size="leaderboard" />
      
      {/* 4. Movies */}
      <MoviesRow />

      {/* Series */}
      <SeriesRow />
      
      {/* 5. Trending Row */}
      <TrendingRow />
      
      {/* 5. Genres/Categories */}
      <GenresPills />
      
      {/* 6. Recently Added */}
      <RecentlyAdded />
      
      {/* 7. Footer */}
      <Footer />
    </div>
  );
};

export default Index;
