export interface Episode {
  id: string;
  number: number;
  title: string;
  duration: string;
  thumbnail: string;
  quality: string[];
  downloadLinks: {
    quality: string;
    size: string;
    url: string;
  }[];
}

export interface Language {
  name: string;
  type: string;
}

export interface Anime {
  id: string;
  title: string;
  japaneseTitle: string;
  image: string;
  coverImage: string;
  rating: number;
  year: string;
  status: "Ongoing" | "Completed" | "Upcoming";
  genre: string[];
  quality: string;
  episodes: Episode[];
  synopsis: string;
  studio: string;
  duration: string;
  views: string;
  type: "Movie" | "Series" | "OVA" | "Special";
  // Enhanced metadata fields
  originalRun: string;
  runningTime: string;
  languages: Language[];
  subtitles: string[];
  encoder: string;
  uploadCredit: string;
}

export const animeData: Anime[] = [
  {
    id: "demon-slayer-mugen-train",
    title: "Demon Slayer: Mugen Train",
    japaneseTitle: "鬼滅の刃 無限列車編",
    image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1920&h=600&fit=crop",
    rating: 9.2,
    year: "2021",
    status: "Completed",
    genre: ["Action", "Supernatural", "Drama"],
    quality: "4K",
    studio: "ufotable",
    duration: "1h 57m",
    views: "15.2M",
    type: "Movie",
    originalRun: "Movie (2020)",
    runningTime: "1h 57m",
    languages: [
      { name: "Japanese 2.0", type: "BD" },
      { name: "English 5.1", type: "BD" },
      { name: "Hindi 2.0", type: "Org. WEB Audio" }
    ],
    subtitles: ["English", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "Tanjiro and his friends board the Mugen Train to join the Flame Hashira Rengoku on a mission to hunt down a powerful demon that has been devouring passengers. What follows is an emotional and action-packed adventure that tests the limits of their resolve and showcases the true meaning of being a Demon Slayer.",
    episodes: [
      {
        id: "mugen-train-full",
        number: 1,
        title: "Mugen Train - Full Movie",
        duration: "1h 57m",
        thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&h=170&fit=crop",
        quality: ["4K", "1080p", "720p", "480p"],
        downloadLinks: [
          { quality: "4K", size: "8.5 GB", url: "#" },
          { quality: "1080p", size: "2.1 GB", url: "#" },
          { quality: "720p", size: "900 MB", url: "#" },
          { quality: "480p", size: "400 MB", url: "#" },
        ],
      },
    ],
  },
  {
    id: "your-name",
    title: "Your Name",
    japaneseTitle: "君の名は。",
    image: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=1920&h=600&fit=crop",
    rating: 8.9,
    year: "2016",
    status: "Completed",
    genre: ["Romance", "Fantasy", "Drama"],
    quality: "1080p",
    studio: "CoMix Wave Films",
    duration: "1h 52m",
    views: "25.8M",
    type: "Movie",
    originalRun: "Movie (2016)",
    runningTime: "1h 52m",
    languages: [
      { name: "Japanese 5.1", type: "BD" },
      { name: "English 5.1", type: "BD" },
      { name: "Hindi 2.0", type: "WEB Audio" }
    ],
    subtitles: ["English", "Hindi", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "Two strangers find themselves linked in a bizarre way. When a connection forms, will distance be the only thing to keep them apart? Mitsuha, a high school girl from a rural town, and Taki, a high school boy from Tokyo, begin to swap bodies mysteriously.",
    episodes: [
      {
        id: "your-name-full",
        number: 1,
        title: "Your Name - Full Movie",
        duration: "1h 52m",
        thumbnail: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=300&h=170&fit=crop",
        quality: ["1080p", "720p", "480p"],
        downloadLinks: [
          { quality: "1080p", size: "2.3 GB", url: "#" },
          { quality: "720p", size: "1.1 GB", url: "#" },
          { quality: "480p", size: "500 MB", url: "#" },
        ],
      },
    ],
  },
  {
    id: "attack-on-titan-final",
    title: "Attack on Titan: Final Season",
    japaneseTitle: "進撃の巨人 The Final Season",
    image: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=1920&h=600&fit=crop",
    rating: 9.5,
    year: "2023",
    status: "Completed",
    genre: ["Action", "Drama", "Fantasy"],
    quality: "4K",
    studio: "MAPPA",
    duration: "24 min/ep",
    views: "45.3M",
    type: "Series",
    originalRun: "TV Series (2013–2023)",
    runningTime: "24min",
    languages: [
      { name: "Japanese 2.0", type: "BD" },
      { name: "English 2.0", type: "BD" },
      { name: "Hindi 2.0", type: "Org. WEB Audio" }
    ],
    subtitles: ["English", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "The epic conclusion to the Attack on Titan saga. As humanity's last hope faces its greatest threat, Eren and the Survey Corps must make impossible choices that will determine the fate of the world.",
    episodes: [
      { id: "aot-ep1", number: 1, title: "The Final Chapters - Part 1", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "1.2 GB", url: "#" }, { quality: "1080p", size: "500 MB", url: "#" }, { quality: "720p", size: "250 MB", url: "#" }] },
      { id: "aot-ep2", number: 2, title: "The Final Chapters - Part 2", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "1.2 GB", url: "#" }, { quality: "1080p", size: "500 MB", url: "#" }, { quality: "720p", size: "250 MB", url: "#" }] },
      { id: "aot-ep3", number: 3, title: "The Rumbling", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1560972550-aba3456b5564?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "1.3 GB", url: "#" }, { quality: "1080p", size: "550 MB", url: "#" }, { quality: "720p", size: "280 MB", url: "#" }] },
    ],
  },
  {
    id: "jujutsu-kaisen-0",
    title: "Jujutsu Kaisen 0",
    japaneseTitle: "劇場版 呪術廻戦 0",
    image: "https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=1920&h=600&fit=crop",
    rating: 8.7,
    year: "2022",
    status: "Completed",
    genre: ["Action", "Supernatural", "Horror"],
    quality: "1080p",
    studio: "MAPPA",
    duration: "1h 45m",
    views: "12.1M",
    type: "Movie",
    originalRun: "Movie (2021)",
    runningTime: "1h 45m",
    languages: [
      { name: "Japanese 5.1", type: "BD" },
      { name: "English 5.1", type: "BD" }
    ],
    subtitles: ["English", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "Yuta Okkotsu is a nervous high school student who is suffering from a serious problem—his childhood friend Rika has turned into a curse and won't leave him alone. Gojo Satoru enrolls him at Jujutsu High to help him control his power.",
    episodes: [
      { id: "jjk0-full", number: 1, title: "Jujutsu Kaisen 0 - Full Movie", duration: "1h 45m", thumbnail: "https://images.unsplash.com/photo-1618336753974-aae8e04506aa?w=300&h=170&fit=crop", quality: ["1080p", "720p", "480p"], downloadLinks: [{ quality: "1080p", size: "2.0 GB", url: "#" }, { quality: "720p", size: "900 MB", url: "#" }, { quality: "480p", size: "450 MB", url: "#" }] },
    ],
  },
  {
    id: "spirited-away",
    title: "Spirited Away",
    japaneseTitle: "千と千尋の神隠し",
    image: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=1920&h=600&fit=crop",
    rating: 9.3,
    year: "2001",
    status: "Completed",
    genre: ["Fantasy", "Adventure", "Family"],
    quality: "1080p",
    studio: "Studio Ghibli",
    duration: "2h 5m",
    views: "35.6M",
    type: "Movie",
    originalRun: "Movie (2001)",
    runningTime: "2h 5m",
    languages: [
      { name: "Japanese 5.1", type: "BD" },
      { name: "English 5.1", type: "BD" },
      { name: "Hindi 2.0", type: "WEB Audio" }
    ],
    subtitles: ["English", "Hindi", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "During her family's move to the suburbs, a sullen 10-year-old girl wanders into a world ruled by gods, witches, and spirits, and where humans are changed into beasts. Chihiro must work in a bathhouse to save her parents and return to the human world.",
    episodes: [
      { id: "spirited-full", number: 1, title: "Spirited Away - Full Movie", duration: "2h 5m", thumbnail: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=170&fit=crop", quality: ["1080p", "720p", "480p"], downloadLinks: [{ quality: "1080p", size: "2.4 GB", url: "#" }, { quality: "720p", size: "1.2 GB", url: "#" }, { quality: "480p", size: "600 MB", url: "#" }] },
    ],
  },
  {
    id: "one-piece-red",
    title: "One Piece Film: Red",
    japaneseTitle: "ONE PIECE FILM RED",
    image: "https://images.unsplash.com/photo-1569701813229-33284b643e3c?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1569701813229-33284b643e3c?w=1920&h=600&fit=crop",
    rating: 8.5,
    year: "2022",
    status: "Completed",
    genre: ["Action", "Adventure", "Comedy"],
    quality: "4K",
    studio: "Toei Animation",
    duration: "1h 55m",
    views: "18.9M",
    type: "Movie",
    originalRun: "Movie (2022)",
    runningTime: "1h 55m",
    languages: [
      { name: "Japanese 5.1", type: "BD" },
      { name: "English 5.1", type: "BD" },
      { name: "Hindi 2.0", type: "Org. WEB Audio" }
    ],
    subtitles: ["English", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "Uta—the most beloved singer in the world. Her voice, which she sings with while concealing her true identity, has been described as 'otherworldly.' She will appear in public for the first time at a live concert.",
    episodes: [
      { id: "op-red-full", number: 1, title: "One Piece Film: Red - Full Movie", duration: "1h 55m", thumbnail: "https://images.unsplash.com/photo-1569701813229-33284b643e3c?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "7.8 GB", url: "#" }, { quality: "1080p", size: "2.2 GB", url: "#" }, { quality: "720p", size: "950 MB", url: "#" }] },
    ],
  },
  {
    id: "solo-leveling",
    title: "Solo Leveling",
    japaneseTitle: "俺だけレベルアップな件",
    image: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=1920&h=600&fit=crop",
    rating: 9.1,
    year: "2024",
    status: "Ongoing",
    genre: ["Action", "Fantasy", "Adventure"],
    quality: "4K",
    studio: "A-1 Pictures",
    duration: "24 min/ep",
    views: "28.4M",
    type: "Series",
    originalRun: "TV Series (2024–)",
    runningTime: "24min",
    languages: [
      { name: "Japanese 2.0", type: "BD" },
      { name: "English 2.0", type: "WEB Audio" },
      { name: "Hindi 2.0", type: "Org. WEB Audio" }
    ],
    subtitles: ["English", "Hindi", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "In a world where hunters with superhuman abilities fight monsters to protect humanity, Sung Jinwoo, the weakest hunter, gains the power to level up infinitely after a near-death experience in a double dungeon.",
    episodes: [
      { id: "sl-ep1", number: 1, title: "I'm Used to It", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "1.4 GB", url: "#" }, { quality: "1080p", size: "600 MB", url: "#" }, { quality: "720p", size: "300 MB", url: "#" }] },
      { id: "sl-ep2", number: 2, title: "If I Had One More Chance", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "1.3 GB", url: "#" }, { quality: "1080p", size: "580 MB", url: "#" }, { quality: "720p", size: "290 MB", url: "#" }] },
      { id: "sl-ep3", number: 3, title: "It's Like a Game", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1614728263952-84ea256f9679?w=300&h=170&fit=crop", quality: ["4K", "1080p", "720p"], downloadLinks: [{ quality: "4K", size: "1.5 GB", url: "#" }, { quality: "1080p", size: "650 MB", url: "#" }, { quality: "720p", size: "320 MB", url: "#" }] },
    ],
  },
  {
    id: "frieren",
    title: "Frieren: Beyond Journey's End",
    japaneseTitle: "葬送のフリーレン",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop",
    coverImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920&h=600&fit=crop",
    rating: 9.4,
    year: "2023",
    status: "Ongoing",
    genre: ["Fantasy", "Adventure", "Drama"],
    quality: "1080p",
    studio: "Madhouse",
    duration: "24 min/ep",
    views: "22.1M",
    type: "Series",
    originalRun: "TV Series (2023–)",
    runningTime: "24min",
    languages: [
      { name: "Japanese 2.0", type: "BD" },
      { name: "English 2.0", type: "WEB Audio" }
    ],
    subtitles: ["English", "Signs & Songs"],
    encoder: "TOON WORLD",
    uploadCredit: "Admin",
    synopsis: "After the party of heroes defeated the Demon King, they restored peace to the land. Frieren, the mage, reflects on their journey and realizes she never truly understood her companions. Now she embarks on a new journey to learn more about humans.",
    episodes: [
      { id: "fr-ep1", number: 1, title: "The Journey's End", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=170&fit=crop", quality: ["1080p", "720p"], downloadLinks: [{ quality: "1080p", size: "500 MB", url: "#" }, { quality: "720p", size: "250 MB", url: "#" }] },
      { id: "fr-ep2", number: 2, title: "It Didn't Have to Be Magic...", duration: "24 min", thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=170&fit=crop", quality: ["1080p", "720p"], downloadLinks: [{ quality: "1080p", size: "520 MB", url: "#" }, { quality: "720p", size: "260 MB", url: "#" }] },
    ],
  },
];

export const genres = [
  "Action", "Adventure", "Comedy", "Drama", "Fantasy", 
  "Horror", "Romance", "Sci-Fi", "Supernatural", "Family"
];

export const years = ["2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2010-2014", "2000-2009", "Before 2000"];

export const qualities = ["4K", "1080p", "720p", "480p"];

export const ratings = ["9+", "8+", "7+", "6+", "Any"];
