import { Link } from "react-router-dom";
import { Film, Github, Twitter, Instagram, Youtube, Mail, FileText, Shield, Scale } from "lucide-react";

const Footer = () => {
  const legalLinks = [
    { name: "Contact", href: "/contact", icon: Mail },
    { name: "DMCA", href: "/dmca", icon: Shield },
    { name: "Privacy Policy", href: "/privacy", icon: FileText },
    { name: "Terms of Service", href: "/terms", icon: Scale },
  ];

  const socialLinks = [
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Youtube, href: "#", label: "YouTube" },
    { icon: Github, href: "#", label: "GitHub" },
  ];

  return (
    <footer className="bg-card border-t border-border">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-10">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2">
              <div className="relative">
                <Film className="h-7 w-7 text-primary" />
                <div className="absolute inset-0 blur-lg bg-primary/50" />
              </div>
              <span className="brand-text text-lg gradient-text">
                iKillAnime Hub
              </span>
            </Link>
          </div>

          {/* Legal Links */}
          <div className="flex flex-wrap items-center gap-6">
            {legalLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Social Links */}
          <div className="flex gap-3">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  className="p-2 rounded-lg bg-muted hover:bg-primary/20 hover:text-primary transition-colors"
                  aria-label={social.label}
                >
                  <Icon className="h-4 w-4" />
                </a>
              );
            })}
          </div>
        </div>
      </div>

      {/* Disclaimer & Copyright */}
      <div className="border-t border-border">
        <div className="container mx-auto px-4 py-6">
          <div className="space-y-4">
            {/* Disclaimer */}
            <p className="text-xs text-muted-foreground text-center max-w-3xl mx-auto">
              We do not host any files on our server. All anime content links are provided by external community sources. 
              If you believe that your copyrighted content is being infringed, please submit a DMCA notice.
            </p>
            
            {/* Copyright */}
            <p className="text-xs text-muted-foreground text-center">
              © {new Date().getFullYear()} iKillAnime Hub. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
