import { Link } from "react-router-dom";
import { 
  Sword, Heart, Ghost, Rocket, Laugh, Zap, Crown, Sparkles, 
  Film, Tv 
} from "lucide-react";

const genres = [
  { name: "Action", icon: Sword, color: "from-red-500 to-orange-500" },
  { name: "Romance", icon: Heart, color: "from-pink-500 to-rose-500" },
  { name: "Fantasy", icon: Sparkles, color: "from-fuchsia-500 to-pink-500" },
  { name: "Isekai", icon: Crown, color: "from-emerald-500 to-teal-500" },
  { name: "Horror", icon: Ghost, color: "from-purple-600 to-violet-600" },
  { name: "Comedy", icon: Laugh, color: "from-yellow-500 to-amber-500" },
  { name: "Sci-Fi", icon: Rocket, color: "from-cyan-500 to-blue-500" },
  { name: "Supernatural", icon: Zap, color: "from-indigo-500 to-purple-500" },
];

const typeFilters = [
  { name: "Movies", icon: Film, href: "/search?type=Movie" },
  { name: "Series", icon: Tv, href: "/search?type=Series" },
];

const GenresPills = () => {
  return (
    <section className="py-8 bg-surface-darker">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <h2 className="font-display text-xl md:text-2xl font-bold mb-6 text-center">
          Browse by <span className="gradient-text">Genre</span>
        </h2>

        {/* Genre Pills */}
        <div className="flex flex-wrap justify-center gap-3">
          {genres.map((genre) => {
            const Icon = genre.icon;
            return (
              <Link
                key={genre.name}
                to={`/search?genre=${genre.name}`}
                className="group flex items-center gap-2 px-4 py-2 rounded-full bg-card border border-border hover:border-primary/50 transition-all duration-300"
              >
                <div className={`p-1.5 rounded-full bg-gradient-to-br ${genre.color}`}>
                  <Icon className="h-3.5 w-3.5 text-white" />
                </div>
                <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                  {genre.name}
                </span>
              </Link>
            );
          })}
          
          {/* Divider */}
          <div className="w-px h-8 bg-border hidden md:block" />
          
          {/* Type Filters */}
          {typeFilters.map((filter) => {
            const Icon = filter.icon;
            return (
              <Link
                key={filter.name}
                to={filter.href}
                className="group flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 hover:bg-primary/20 transition-all duration-300"
              >
                <Icon className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium text-primary">
                  {filter.name}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default GenresPills;
