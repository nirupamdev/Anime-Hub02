import { Link } from "react-router-dom";
import { Star, Film, ArrowRight } from "lucide-react";
import { animeData } from "@/data/animeData";

const MoviesRow = () => {
  const movies = animeData.filter((a) => a.type === "Movie").slice(0, 10);

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Film className="h-5 w-5 text-primary" />
            <h2 className="font-display text-xl md:text-2xl font-bold">
              <span className="gradient-text">Movies</span>
            </h2>
          </div>
          <Link
            to="/search?type=Movie"
            className="flex items-center gap-1 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
          >
            View All
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="relative -mx-4 px-4">
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory">
            {movies.map((anime, index) => (
              <Link
                key={anime.id}
                to={`/anime/${anime.id}`}
                className="flex-shrink-0 w-[140px] md:w-[160px] snap-start group"
              >
                <div className="relative aspect-[2/3] rounded-lg overflow-hidden mb-2">
                  <img
                    src={anime.image}
                    alt={anime.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />

                  <div className="absolute bottom-0 left-0 bg-gradient-to-r from-primary to-secondary px-2 py-1 rounded-tr-lg">
                    <span className="text-primary-foreground font-bold text-sm">
                      #{index + 1}
                    </span>
                  </div>

                  <div className="absolute top-2 right-2 flex items-center gap-1 px-1.5 py-0.5 rounded bg-background/80 backdrop-blur-sm">
                    <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                    <span className="text-xs font-medium">{anime.rating}</span>
                  </div>
                </div>

                <h3 className="anime-title text-sm text-foreground line-clamp-2 group-hover:text-primary transition-colors">
                  {anime.title}
                </h3>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MoviesRow;
