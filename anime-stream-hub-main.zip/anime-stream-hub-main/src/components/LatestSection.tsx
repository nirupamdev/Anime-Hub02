import { Link } from "react-router-dom";
import { Clock, Eye, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { animeData } from "@/data/animeData";

const LatestSection = () => {
  const latestReleases = animeData
    .filter((a) => a.status === "Ongoing" || parseInt(a.year) >= 2023)
    .slice(0, 3)
    .map((anime) => ({
      id: anime.id,
      title: anime.title,
      episode: anime.type === "Movie" ? "Full Movie" : `${anime.episodes.length} Episodes`,
      image: anime.coverImage,
      views: anime.views,
      time: anime.status === "Ongoing" ? "New episode" : anime.year,
      quality: anime.quality,
    }));

  return (
    <section id="latest" className="py-20 bg-surface-darker">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
          <div>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-2">
              <span className="gradient-text">Latest</span> Releases
            </h2>
            <p className="text-muted-foreground">
              Fresh episodes and movies just added
            </p>
          </div>
          <Link
            to="/search"
            className="text-primary hover:text-primary/80 transition-colors text-sm font-medium flex items-center gap-1"
          >
            View All
            <span className="text-lg">→</span>
          </Link>
        </div>

        {/* Latest Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {latestReleases.map((release) => (
            <Link
              key={release.id}
              to={`/anime/${release.id}`}
              className="group relative overflow-hidden rounded-xl bg-card border border-border hover:border-primary/50 transition-all duration-300"
            >
              {/* Image */}
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={release.image}
                  alt={release.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                
                {/* Quality Badge */}
                <div className="absolute top-3 right-3 px-2 py-1 rounded-md bg-primary/90 backdrop-blur-sm">
                  <span className="text-xs font-bold text-primary-foreground">
                    {release.quality}
                  </span>
                </div>

                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button variant="neon" size="lg" className="rounded-full">
                    <Download className="h-5 w-5 mr-2" />
                    Download Now
                  </Button>
                </div>
              </div>

              {/* Content */}
              <div className="p-4 space-y-3">
                <div>
                  <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors">
                    {release.title}
                  </h3>
                  <p className="text-sm text-secondary">{release.episode}</p>
                </div>

                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Eye className="h-3 w-3" />
                    {release.views} views
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {release.time}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LatestSection;
