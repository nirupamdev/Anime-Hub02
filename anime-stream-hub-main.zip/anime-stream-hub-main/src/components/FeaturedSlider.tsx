import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { animeData } from "@/data/animeData";

const FeaturedSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const featuredAnime = animeData.slice(0, 5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredAnime.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [featuredAnime.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredAnime.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredAnime.length) % featuredAnime.length);
  };

  return (
    <section className="relative w-full pt-20">
      {/* Main Slider */}
      <div className="relative h-[400px] md:h-[500px] lg:h-[600px] overflow-hidden">
        {featuredAnime.map((anime, index) => (
          <div
            key={anime.id}
            className={`absolute inset-0 transition-all duration-700 ease-in-out ${
              index === currentSlide 
                ? "opacity-100 translate-x-0" 
                : index < currentSlide 
                  ? "opacity-0 -translate-x-full" 
                  : "opacity-0 translate-x-full"
            }`}
          >
            {/* Background Image */}
            <div className="absolute inset-0">
              <img
                src={anime.coverImage}
                alt={anime.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
            </div>

            {/* Content */}
            <div className="relative h-full container mx-auto px-4 flex items-center">
              <div className="max-w-2xl space-y-4 md:space-y-6">
                {/* Type Badge */}
                <div className="inline-flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium border border-primary/30">
                    {anime.type}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-secondary/20 text-secondary text-sm font-medium border border-secondary/30">
                    {anime.quality}
                  </span>
                </div>

                {/* Title */}
                <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                  {anime.title}
                </h2>

                {/* Description */}
                <p className="text-muted-foreground text-sm md:text-base line-clamp-2 md:line-clamp-3 max-w-xl">
                  {anime.synopsis}
                </p>

                {/* Meta */}
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <span className="text-yellow-500">★</span> {anime.rating}
                  </span>
                  <span>{anime.year}</span>
                  <span>{anime.genre.slice(0, 2).join(" • ")}</span>
                </div>

                {/* Action Button */}
                <Link to={`/anime/${anime.id}`}>
                  <Button variant="neon" size="lg" className="mt-2">
                    View Details
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-background/50 backdrop-blur-sm border border-border hover:bg-background/80 transition-colors z-10"
          aria-label="Previous slide"
        >
          <ChevronLeft className="h-6 w-6" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-background/50 backdrop-blur-sm border border-border hover:bg-background/80 transition-colors z-10"
          aria-label="Next slide"
        >
          <ChevronRight className="h-6 w-6" />
        </button>

        {/* Dots Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
          {featuredAnime.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentSlide
                  ? "bg-primary w-8"
                  : "bg-muted-foreground/50 hover:bg-muted-foreground"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedSlider;
