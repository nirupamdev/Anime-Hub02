import { Link } from "react-router-dom";
import { Clock, Film, Tv } from "lucide-react";
import { animeData } from "@/data/animeData";

const RecentlyAdded = () => {
  // Get recent items - prioritize ongoing and recent years
  const recentItems = animeData
    .filter((a) => a.status === "Ongoing" || parseInt(a.year) >= 2022)
    .slice(0, 6)
    .map((anime) => ({
      id: anime.id,
      title: anime.title,
      thumbnail: anime.image,
      type: anime.type,
      episode: anime.type === "Movie" 
        ? "Full Movie" 
        : `EP ${anime.episodes.length}`,
      time: anime.status === "Ongoing" ? "Just added" : anime.year,
    }));

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center gap-2 mb-6">
          <Clock className="h-5 w-5 text-secondary" />
          <h2 className="font-display text-xl md:text-2xl font-bold">
            Recently <span className="text-secondary">Added</span>
          </h2>
        </div>

        {/* Compact List */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {recentItems.map((item) => (
            <Link
              key={item.id}
              to={`/anime/${item.id}`}
              className="group flex gap-4 p-3 rounded-lg bg-card border border-border hover:border-primary/50 transition-all duration-300"
            >
              {/* Thumbnail */}
              <div className="relative w-16 h-24 flex-shrink-0 rounded overflow-hidden">
                <img
                  src={item.thumbnail}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0 flex flex-col justify-center">
                <h3 className="anime-title text-foreground text-sm line-clamp-2 group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                
                <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    {item.type === "Movie" ? (
                      <Film className="h-3 w-3" />
                    ) : (
                      <Tv className="h-3 w-3" />
                    )}
                    {item.episode}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {item.time}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RecentlyAdded;
