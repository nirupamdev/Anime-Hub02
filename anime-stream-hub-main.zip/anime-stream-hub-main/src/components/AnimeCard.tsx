import { Play, Download, Star, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AnimeCardProps {
  title: string;
  image: string;
  rating: number;
  year: string;
  episodes?: string;
  genre: string;
}

const AnimeCard = ({ title, image, rating, year, episodes, genre }: AnimeCardProps) => {
  return (
    <div className="anime-card group cursor-pointer">
      {/* Image Container */}
      <div className="relative aspect-[2/3] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Rating Badge */}
        <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-md bg-background/80 backdrop-blur-sm">
          <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
          <span className="text-xs font-medium">{rating}</span>
        </div>

        {/* Genre Badge */}
        <div className="absolute top-3 left-3 px-2 py-1 rounded-md bg-secondary/80 backdrop-blur-sm">
          <span className="text-xs font-medium">{genre}</span>
        </div>

        {/* Action Buttons */}
        <div className="absolute inset-0 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button variant="neon" size="icon" className="h-12 w-12 rounded-full">
            <Play className="h-5 w-5 fill-current" />
          </Button>
          <Button variant="neonOutline" size="icon" className="h-12 w-12 rounded-full">
            <Download className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-2">
        <h3 className="anime-title text-foreground line-clamp-1 group-hover:text-primary transition-colors">
          {title}
        </h3>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {year}
          </span>
          {episodes && <span>{episodes}</span>}
        </div>
      </div>
    </div>
  );
};

export default AnimeCard;
