interface AdPlaceholderProps {
  className?: string;
  size?: "banner" | "rectangle" | "leaderboard";
}

const AdPlaceholder = ({ className = "", size = "banner" }: AdPlaceholderProps) => {
  const sizeClasses = {
    banner: "h-[90px] max-w-[728px]",
    rectangle: "h-[250px] max-w-[300px]",
    leaderboard: "h-[90px] max-w-[970px]",
  };

  return (
    <div className={`w-full flex justify-center py-4 ${className}`}>
      <div
        className={`${sizeClasses[size]} w-full bg-muted/30 border border-dashed border-border rounded-lg flex items-center justify-center`}
      >
        <span className="text-muted-foreground text-sm">Advertisement</span>
      </div>
    </div>
  );
};

export default AdPlaceholder;
