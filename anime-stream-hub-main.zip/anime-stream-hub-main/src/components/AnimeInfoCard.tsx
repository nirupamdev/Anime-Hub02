import { Anime } from "@/data/animeData";
import { Info } from "lucide-react";

interface AnimeInfoCardProps {
  anime: Anime;
}

const AnimeInfoCard = ({ anime }: AnimeInfoCardProps) => {
  const getQualityLabel = (quality: string) => {
    switch (quality) {
      case "4K":
        return "4K UHD";
      case "1080p":
        return "1080p FHD";
      case "720p":
        return "720p HD";
      default:
        return quality;
    }
  };

  return (
    <div className="glass-card border border-primary/30 rounded-xl overflow-hidden">
      {/* Header */}
      <div className="px-5 py-3 bg-primary/10 border-b border-primary/20 flex items-center gap-2">
        <Info className="h-4 w-4 text-primary" />
        <h3 className="font-display text-sm font-semibold tracking-wider text-primary uppercase">
          Information
        </h3>
      </div>

      {/* Content */}
      <div className="p-5 space-y-3">
        {/* Genre */}
        <InfoRow 
          label="Genre" 
          value={anime.genre.join(" | ")} 
        />

        {/* Original Run */}
        <InfoRow 
          label="Org. Run" 
          value={anime.originalRun} 
        />

        {/* Running Time */}
        <InfoRow 
          label="Running Time" 
          value={anime.runningTime} 
        />

        {/* Languages */}
        <div className="flex gap-3">
          <span className="text-muted-foreground text-sm min-w-[100px] shrink-0">Language:</span>
          <div className="flex flex-wrap gap-1.5">
            {anime.languages.map((lang, index) => (
              <span key={index} className="text-foreground text-sm">
                {lang.name}
                {lang.type && (
                  <span className="text-primary ml-1 text-xs">[{lang.type}]</span>
                )}
                {index < anime.languages.length - 1 && (
                  <span className="text-muted-foreground mx-1">–</span>
                )}
              </span>
            ))}
          </div>
        </div>

        {/* Season */}
        <InfoRow 
          label="Season" 
          value={anime.type === "Series" ? "1" : "—"} 
        />

        {/* Episodes */}
        <InfoRow 
          label="Episodes" 
          value={anime.episodes.length.toString()} 
        />

        {/* Subtitles */}
        <InfoRow 
          label="Subtitle" 
          value={anime.subtitles.join(", ")} 
        />

        {/* Quality */}
        <div className="flex gap-3">
          <span className="text-muted-foreground text-sm min-w-[100px] shrink-0">Quality:</span>
          <span className="px-2 py-0.5 bg-primary/20 text-primary text-sm font-medium rounded">
            {getQualityLabel(anime.quality)}
          </span>
        </div>

        {/* Encoder */}
        <InfoRow 
          label="Encoder" 
          value="Admin" 
          highlight 
        />

        {/* Upload Credit */}
        <InfoRow 
          label="Up Credit" 
          value={anime.uploadCredit} 
          highlight 
        />
      </div>
    </div>
  );
};

interface InfoRowProps {
  label: string;
  value: string;
  highlight?: boolean;
}

const InfoRow = ({ label, value, highlight }: InfoRowProps) => (
  <div className="flex gap-3">
    <span className="text-muted-foreground text-sm min-w-[100px] shrink-0">{label}:</span>
    <span className={`text-sm ${highlight ? "text-primary font-medium" : "text-foreground"}`}>
      {value}
    </span>
  </div>
);

export default AnimeInfoCard;
