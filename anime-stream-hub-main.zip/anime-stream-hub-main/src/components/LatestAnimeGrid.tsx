import { Link } from "react-router-dom";
import { Star, Calendar, Film, Tv, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { animeData } from "@/data/animeData";
import { useInfiniteScroll } from "@/hooks/useInfiniteScroll";

const LatestAnimeGrid = () => {
  const {
    displayedItems: latestAnime,
    hasMore,
    isLoading,
    observerRef,
  } = useInfiniteScroll({
    data: animeData,
    itemsPerPage: 8,
    threshold: 200,
  });

  return (
    <section className="py-12 md:py-16">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-display text-2xl md:text-3xl font-bold">
              <span className="gradient-text">Latest</span> Anime
            </h2>
            <p className="text-muted-foreground text-sm mt-1">
              Recently added movies and series
            </p>
          </div>
          <Link
            to="/search?sort=year"
            className="text-primary hover:text-primary/80 transition-colors text-sm font-medium"
          >
            View All →
          </Link>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {latestAnime.map((anime) => (
            <Link
              key={anime.id}
              to={`/anime/${anime.id}`}
              className="group bg-card rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-all duration-300"
            >
              {/* Poster */}
              <div className="relative aspect-[2/3] overflow-hidden">
                <img
                  src={anime.image}
                  alt={anime.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                
                {/* Quality Badge */}
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-primary text-primary-foreground text-xs font-bold">
                  {anime.quality}
                </div>

                {/* Type Badge */}
                <div className="absolute top-2 right-2 p-1.5 rounded bg-background/80 backdrop-blur-sm">
                  {anime.type === "Movie" ? (
                    <Film className="h-3.5 w-3.5 text-secondary" />
                  ) : (
                    <Tv className="h-3.5 w-3.5 text-secondary" />
                  )}
                </div>

                {/* Overlay on Hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-4">
                  <Button variant="neon" size="sm">
                    View Details
                  </Button>
                </div>
              </div>

              {/* Info */}
              <div className="p-3 space-y-1.5">
                <h3 className="anime-title text-foreground text-sm line-clamp-2 group-hover:text-primary transition-colors min-h-[2.5rem]">
                  {anime.title}
                </h3>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    {anime.type === "Movie" ? (
                      <Film className="h-3 w-3" />
                    ) : (
                      <Tv className="h-3 w-3" />
                    )}
                    {anime.type}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {anime.year}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-xs">
                  <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                  <span className="text-foreground font-medium">{anime.rating}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Infinite Scroll Observer */}
        <div ref={observerRef} className="h-4" />

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        )}

        {/* End Message */}
        {!hasMore && latestAnime.length > 8 && (
          <p className="text-center text-muted-foreground text-sm py-8">
            You've seen all {latestAnime.length} anime titles
          </p>
        )}
      </div>
    </section>
  );
};

export default LatestAnimeGrid;
