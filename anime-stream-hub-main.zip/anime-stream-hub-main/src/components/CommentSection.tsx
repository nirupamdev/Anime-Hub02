import { useState } from "react";
import { MessageCircle, ThumbsUp, Reply, Send, User } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Comment {
  id: string;
  user: string;
  avatar: string;
  content: string;
  likes: number;
  time: string;
  replies?: Comment[];
}

interface CommentSectionProps {
  animeId: string;
}

// Mock comments data
const mockComments: Comment[] = [
  {
    id: "1",
    user: "AnimeKing99",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop",
    content: "This anime is absolutely incredible! The animation quality is top-tier and the story keeps you on the edge of your seat. Highly recommend!",
    likes: 234,
    time: "2 hours ago",
    replies: [
      {
        id: "1-1",
        user: "OtakuFan",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
        content: "Totally agree! The fight scenes are breathtaking.",
        likes: 45,
        time: "1 hour ago",
      },
    ],
  },
  {
    id: "2",
    user: "MangaReader42",
    avatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&h=100&fit=crop",
    content: "As someone who read the manga, I was worried about the adaptation but they nailed it! The pacing is perfect.",
    likes: 156,
    time: "5 hours ago",
  },
  {
    id: "3",
    user: "NightOwl_Anime",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    content: "The soundtrack is absolutely phenomenal. Does anyone know who composed it?",
    likes: 89,
    time: "1 day ago",
    replies: [
      {
        id: "3-1",
        user: "MusicLover",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
        content: "It's composed by the legendary Hiroyuki Sawano! He also did Attack on Titan.",
        likes: 67,
        time: "20 hours ago",
      },
    ],
  },
];

const CommentSection = ({ animeId }: CommentSectionProps) => {
  const [comments, setComments] = useState<Comment[]>(mockComments);
  const [newComment, setNewComment] = useState("");
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    
    const comment: Comment = {
      id: Date.now().toString(),
      user: "Guest User",
      avatar: "https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=100&h=100&fit=crop",
      content: newComment,
      likes: 0,
      time: "Just now",
    };
    
    setComments([comment, ...comments]);
    setNewComment("");
  };

  const handleLike = (commentId: string) => {
    setComments(comments.map(comment => {
      if (comment.id === commentId) {
        return { ...comment, likes: comment.likes + 1 };
      }
      if (comment.replies) {
        return {
          ...comment,
          replies: comment.replies.map(reply =>
            reply.id === commentId ? { ...reply, likes: reply.likes + 1 } : reply
          ),
        };
      }
      return comment;
    }));
  };

  const handleReply = (commentId: string) => {
    if (!replyText.trim()) return;

    const reply: Comment = {
      id: `${commentId}-${Date.now()}`,
      user: "Guest User",
      avatar: "https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=100&h=100&fit=crop",
      content: replyText,
      likes: 0,
      time: "Just now",
    };

    setComments(comments.map(comment => {
      if (comment.id === commentId) {
        return {
          ...comment,
          replies: [...(comment.replies || []), reply],
        };
      }
      return comment;
    }));

    setReplyingTo(null);
    setReplyText("");
  };

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="font-display text-2xl font-bold mb-6 flex items-center gap-3">
          <MessageCircle className="h-6 w-6 text-primary" />
          Comments
          <span className="text-muted-foreground font-normal text-lg">({comments.length})</span>
        </h2>

        {/* Add Comment */}
        <div className="bg-card border border-border rounded-xl p-4 mb-8">
          <div className="flex gap-4">
            <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
              <User className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Share your thoughts about this anime..."
                rows={3}
                className="w-full bg-muted border border-border rounded-lg px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              />
              <div className="flex justify-end mt-3">
                <Button 
                  variant="neon" 
                  size="sm" 
                  onClick={handleAddComment}
                  disabled={!newComment.trim()}
                  className="gap-2"
                >
                  <Send className="h-4 w-4" />
                  Post Comment
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Comments List */}
        <div className="space-y-6">
          {comments.map((comment) => (
            <div key={comment.id} className="space-y-4">
              {/* Main Comment */}
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex gap-4">
                  <img
                    src={comment.avatar}
                    alt={comment.user}
                    className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-medium text-foreground">{comment.user}</span>
                      <span className="text-sm text-muted-foreground">•</span>
                      <span className="text-sm text-muted-foreground">{comment.time}</span>
                    </div>
                    <p className="text-muted-foreground leading-relaxed mb-3">
                      {comment.content}
                    </p>
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => handleLike(comment.id)}
                        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
                      >
                        <ThumbsUp className="h-4 w-4" />
                        {comment.likes}
                      </button>
                      <button
                        onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
                      >
                        <Reply className="h-4 w-4" />
                        Reply
                      </button>
                    </div>

                    {/* Reply Input */}
                    {replyingTo === comment.id && (
                      <div className="mt-4 flex gap-3">
                        <input
                          type="text"
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          placeholder="Write a reply..."
                          className="flex-1 bg-muted border border-border rounded-lg px-4 py-2 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                          onKeyDown={(e) => e.key === "Enter" && handleReply(comment.id)}
                        />
                        <Button 
                          variant="neon" 
                          size="sm" 
                          onClick={() => handleReply(comment.id)}
                          disabled={!replyText.trim()}
                        >
                          Reply
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Replies */}
              {comment.replies && comment.replies.length > 0 && (
                <div className="ml-12 space-y-4">
                  {comment.replies.map((reply) => (
                    <div key={reply.id} className="bg-muted/30 border border-border rounded-xl p-4">
                      <div className="flex gap-4">
                        <img
                          src={reply.avatar}
                          alt={reply.user}
                          className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="font-medium text-foreground text-sm">{reply.user}</span>
                            <span className="text-xs text-muted-foreground">•</span>
                            <span className="text-xs text-muted-foreground">{reply.time}</span>
                          </div>
                          <p className="text-muted-foreground text-sm leading-relaxed mb-2">
                            {reply.content}
                          </p>
                          <button
                            onClick={() => handleLike(reply.id)}
                            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors"
                          >
                            <ThumbsUp className="h-3 w-3" />
                            {reply.likes}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CommentSection;
