import { Link } from "react-router-dom";
import AnimeCard from "./AnimeCard";
import { animeData } from "@/data/animeData";

const FeaturedSection = () => {
  const featuredAnime = animeData.slice(0, 6);

  return (
    <section id="movies" className="py-20 bg-surface-darker">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
          <div>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-2">
              <span className="gradient-text">Featured</span> Anime
            </h2>
            <p className="text-muted-foreground">
              Top picks and trending anime movies this week
            </p>
          </div>
          <Link
            to="/search"
            className="text-primary hover:text-primary/80 transition-colors text-sm font-medium flex items-center gap-1"
          >
            View All
            <span className="text-lg">→</span>
          </Link>
        </div>

        {/* Anime Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-6">
          {featuredAnime.map((anime) => (
            <Link key={anime.id} to={`/anime/${anime.id}`}>
              <AnimeCard
                title={anime.title}
                image={anime.image}
                rating={anime.rating}
                year={anime.year}
                genre={anime.genre[0]}
              />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedSection;
