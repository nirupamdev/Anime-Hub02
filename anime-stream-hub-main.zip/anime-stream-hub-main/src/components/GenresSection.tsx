import { Sword, Heart, Ghost, Rocket, Laugh, Zap, Crown, Sparkles } from "lucide-react";

const genres = [
  { name: "Action", icon: Sword, color: "from-red-500 to-orange-500" },
  { name: "Romance", icon: Heart, color: "from-pink-500 to-rose-500" },
  { name: "Horror", icon: Ghost, color: "from-purple-600 to-violet-600" },
  { name: "Sci-Fi", icon: Rocket, color: "from-cyan-500 to-blue-500" },
  { name: "Comedy", icon: Laugh, color: "from-yellow-500 to-amber-500" },
  { name: "Supernatural", icon: Zap, color: "from-indigo-500 to-purple-500" },
  { name: "Isekai", icon: Crown, color: "from-emerald-500 to-teal-500" },
  { name: "Fantasy", icon: Sparkles, color: "from-fuchsia-500 to-pink-500" },
];

const GenresSection = () => {
  return (
    <section id="genres" className="py-20">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-2">
            Browse by <span className="neon-text-purple text-secondary">Genre</span>
          </h2>
          <p className="text-muted-foreground">
            Find your favorite anime by category
          </p>
        </div>

        {/* Genres Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
          {genres.map((genre) => {
            const Icon = genre.icon;
            return (
              <a
                key={genre.name}
                href="#"
                className="group relative flex flex-col items-center justify-center p-6 rounded-xl bg-card border border-border hover:border-primary/50 transition-all duration-300 overflow-hidden"
              >
                {/* Background Glow */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${genre.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
                />
                
                {/* Icon */}
                <div className={`relative mb-3 p-3 rounded-full bg-gradient-to-br ${genre.color}`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                
                {/* Name */}
                <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                  {genre.name}
                </span>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default GenresSection;
