import { useState, useEffect, useCallback, useRef } from "react";

interface UseInfiniteScrollOptions<T> {
  data: T[];
  itemsPerPage: number;
  threshold?: number;
}

interface UseInfiniteScrollReturn<T> {
  displayedItems: T[];
  hasMore: boolean;
  isLoading: boolean;
  loadMore: () => void;
  observerRef: React.RefObject<HTMLDivElement>;
  reset: () => void;
}

export function useInfiniteScroll<T>({
  data,
  itemsPerPage,
  threshold = 100,
}: UseInfiniteScrollOptions<T>): UseInfiniteScrollReturn<T> {
  const [displayedCount, setDisplayedCount] = useState(itemsPerPage);
  const [isLoading, setIsLoading] = useState(false);
  const observerRef = useRef<HTMLDivElement>(null);

  const displayedItems = data.slice(0, displayedCount);
  const hasMore = displayedCount < data.length;

  const loadMore = useCallback(() => {
    if (isLoading || !hasMore) return;
    
    setIsLoading(true);
    // Simulate loading delay for smoother UX
    setTimeout(() => {
      setDisplayedCount((prev) => Math.min(prev + itemsPerPage, data.length));
      setIsLoading(false);
    }, 300);
  }, [isLoading, hasMore, itemsPerPage, data.length]);

  const reset = useCallback(() => {
    setDisplayedCount(itemsPerPage);
  }, [itemsPerPage]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoading) {
          loadMore();
        }
      },
      { rootMargin: `${threshold}px` }
    );

    const currentRef = observerRef.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [hasMore, isLoading, loadMore, threshold]);

  // Reset when data changes (e.g., filters applied)
  useEffect(() => {
    setDisplayedCount(itemsPerPage);
  }, [data, itemsPerPage]);

  return {
    displayedItems,
    hasMore,
    isLoading,
    loadMore,
    observerRef,
    reset,
  };
}
